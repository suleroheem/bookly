import React from "react";

import Header from "../header/header";

const Shop = () => {
  return (
    <div>
      <Header />
    </div>
  );
};


export default Shop;