import React from 'react';
import { Link } from 'react-router-dom'


function Register () {
    return(
        <div className="flex justify-center items-center h-screen">
        <div className="bg-white w-96 shadow-md p-8 rounded-lg">
            <h1 className="text-2xl font-bold mb-4 text-center">Register</h1>
            <form className="flex flex-col space-y-4">
                <div>
                    <input className="w-full h-12 px-4 rounded border border-gray-300 focus:outline-none focus:border-violet-800" type="text" placeholder="Enter your name" />
                </div>
                <div>
                    <input className="w-full h-12 px-4 rounded border border-gray-300 focus:outline-none focus:border-violet-800" type="text" placeholder="Enter your email" />
                </div>
                <div>
                    <input className="w-full h-12 px-4 rounded border border-gray-300 focus:outline-none focus:border-violet-800" type="text" placeholder="Enter your preferred username" />
                </div>
                <div>
                    <input className="w-full h-12 px-4 rounded border border-gray-300 focus:outline-none focus:border-violet-800" type="text" placeholder="Enter your phone number" />
                </div>
                <div>
                    <input className="w-full h-12 px-4 rounded border border-gray-300 focus:outline-none focus:border-violet-800" type="password" placeholder="Create your password" />
                </div>
                <div>
                    <input className="w-full h-12 px-4 rounded border border-gray-300 focus:outline-none focus:border-violet-800" type="password" placeholder="Re-enter your password" />
                </div>
                <div>
                    <button className="bg-violet-800 text-white h-10 w-full rounded hover:bg-violet-700 focus:outline-none focus:bg-violet-700" type="submit"><Link to="/"></Link>Register</button>
                </div>
                <div className="text-center">
                    <p>Already have an account? <Link to="/" className="text-violet-800">Log in</Link></p>
                </div>
            </form>
        </div>
    </div>
);
}

export default Register