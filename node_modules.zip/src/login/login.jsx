import React from 'react';
import { Link } from 'react-router-dom';

function Login() {
    return (
        <div className="flex justify-center items-center h-screen">
            <form className="flex flex-col bg-white w-96 h-60 shadow-md p-8 rounded-lg">
                <h1 className="text-xl font-bold mb-4">LOGIN NOW</h1>
                <input className="w-full h-12 px-4 mb-4 rounded border border-gray-300 focus:border-violet-800" type="text" placeholder="Enter Your Username" />
                <input className="w-full h-12 px-4 mb-4 rounded border border-gray-300  focus:border-violet-800" type="password" placeholder="Enter Your Password" />
                <button className="bg-violet-800 text-white h-10 w-full rounded hover:bg-violet-700 focus:outline-none focus:bg-violet-700" type="submit"> <Link to="/homepage">Login Now</Link></button>
                <p className="mt-4 text-center">Don't have an account? <Link to="/Register" className="text-violet-800">Register Now</Link></p>
            </form>
        </div>
    );
}

export default Login;
